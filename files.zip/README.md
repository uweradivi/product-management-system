# 🍔 Food Delivery System — Java OOP Project

A well-structured Java application modeling a real-world food delivery platform.
Demonstrates all five core OOP principles through meaningful, real-world entities.

---

## 📁 Project Structure

```
FoodDeliverySystem/
└── src/main/java/com/fooddelivery/
    ├── Main.java                        ← Entry point / demo
    ├── model/
    │   ├── Person.java                  ← Abstract base class
    │   ├── Customer.java                ← extends Person
    │   ├── DeliveryDriver.java          ← extends Person
    │   ├── Deliverable.java             ← Interface (abstraction)
    │   ├── MenuItem.java                ← implements Deliverable
    │   ├── ComboMeal.java               ← extends MenuItem
    │   ├── Restaurant.java              ← Owns menu items
    │   ├── Order.java                   ← Links all entities
    │   └── OrderStatus.java             ← Enum for order lifecycle
    └── service/
        └── DeliveryService.java         ← Platform coordinator
```

---

## 🧠 OOP Principles Applied

### 1. Classes & Objects
| Class | Real-World Entity |
|---|---|
| `Person` | Any person on the platform |
| `Customer` | A user who orders food |
| `DeliveryDriver` | A person who delivers orders |
| `Restaurant` | A food business on the platform |
| `MenuItem` | A single food/drink item |
| `ComboMeal` | A discounted bundle of items |
| `Order` | A customer's delivery request |
| `DeliveryService` | The platform managing all entities |

---

### 2. Encapsulation
All class fields are **private**. Access is controlled via `getters` and `setters`.

```java
// In Person.java
private String name;
private String email;

public String getName()              { return name; }
public void setName(String name)     { this.name = name; }
```

Business rules are enforced through methods, not raw field access:
```java
// In DeliveryDriver.java — rating capped between 1 and 5
public void setRating(double rating) {
    this.rating = Math.max(1.0, Math.min(5.0, rating));
}
```

---

### 3. Abstraction

**Abstract class `Person`** — defines a contract that all people must fulfill:
```java
public abstract class Person {
    public abstract String getRole();       // What role do you play?
    public abstract void displayInfo();     // How do you show your profile?
}
```

**Interface `Deliverable`** — pure abstraction of what any orderable item must provide:
```java
public interface Deliverable {
    String getName();
    double getPrice();
    String getCategory();
    boolean isAvailable();
}
```

**`DeliveryService`** — hides the entire dispatch workflow behind one method:
```java
platform.dispatchOrder(order);  // caller doesn't see any of the internal steps
```

---

### 4. Inheritance

```
Person  (abstract)
├── Customer          → adds deliveryAddress, orderHistory, placeOrder()
└── DeliveryDriver    → adds vehicleType, rating, acceptDelivery()

MenuItem  (implements Deliverable)
└── ComboMeal         → overrides getPrice() to apply bundle discount
```

```java
public class Customer extends Person { ... }
public class DeliveryDriver extends Person { ... }
public class ComboMeal extends MenuItem { ... }
```

---

### 5. Polymorphism

**Method overriding — same method, different behavior:**
```java
// Called on Customer:
alice.displayInfo();    // → shows customer profile with address & order count

// Called on DeliveryDriver:
driver1.displayInfo();  // → shows driver profile with vehicle type & rating
```

**Interface polymorphism — Order treats all items as `Deliverable`:**
```java
for (Deliverable item : items) {
    total += item.getPrice();  // works for both MenuItem AND ComboMeal
}
```

**ComboMeal overrides `getPrice()`:**
```java
// MenuItem: returns fixed price
// ComboMeal: applies discount to the sum of component items
@Override
public double getPrice() {
    return calculateBasePrice(comboItems) * (1 - discountPercent / 100.0);
}
```

---

## ▶️ How to Run

### Option A — Command Line (javac)
```bash
# From the project root
find src -name "*.java" > sources.txt
javac -d out @sources.txt
java -cp out com.fooddelivery.Main
```

### Option B — IntelliJ IDEA
1. Open the `FoodDeliverySystem` folder as a project
2. Mark `src/main/java` as Sources Root
3. Run `Main.java`

---

## 🗺️ Class Relationship Diagram

```
          ┌─────────────────────────────┐
          │      <<abstract>>           │
          │          Person             │
          │  + getRole(): String        │
          │  + displayInfo(): void      │
          └──────────┬──────────────────┘
                     │ extends
          ┌──────────┴──────────────────┐
          │                             │
    ┌─────┴──────┐          ┌───────────┴──────┐
    │  Customer  │          │  DeliveryDriver  │
    │ -address   │          │ -vehicleType     │
    │ -orders    │          │ -isAvailable     │
    └────────────┘          └──────────────────┘
          │ places                   │ assigned to
          ▼                          ▼
    ┌───────────┐◄──────────────────────────────┐
    │   Order   │                               │
    │ -items    ├──────────► Restaurant         │
    │ -status   │            -menu[]            │
    └───────────┘                               │
          │                                     │
          │ contains                            │
          ▼                                     │
   <<interface>>                                │
    Deliverable ◄────── MenuItem               │
                              ▲                 │
                              │ extends         │
                          ComboMeal             │
```

---

## 🚀 Future Semester Extensions
- **REST API** with Spring Boot
- **Database** persistence with MySQL / JPA
- **Authentication** with JWT
- **Payment** integration
- **Real-time** order tracking

---

*OOP Assignment — Food Delivery System | Java*
